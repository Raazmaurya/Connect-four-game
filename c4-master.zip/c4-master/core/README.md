# @kenrick95/c4

This package contains the building blocks for the game **c4** or **Connect Four** ([playable in browser](https://kenrick95.github.io/c4/))

More info in the repository: https://github.com/kenrick95/c4
